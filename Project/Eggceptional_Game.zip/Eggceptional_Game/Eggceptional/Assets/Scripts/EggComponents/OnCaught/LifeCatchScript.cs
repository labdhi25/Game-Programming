using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LifeCatchScript : MonoBehaviour
{
    public int lifeAdded;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "Basket")
        {
            GameObject gameController = GameObject.Find("GameController");
            if (gameController == null)
                return;
            StandardGameController standardScript = gameController.GetComponent<StandardGameController>();
            standardScript.livesLeft = standardScript.livesLeft + lifeAdded;
        }        
    }
}
