﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StandardGameController : MonoBehaviour
{
    public Camera cam;
    public GameObject egg;
    public int livesLeft;
    public Text LifeText;
    public GameObject gameOverText;
    public GameObject restartButton;
    private float maxWidth;
    public GameObject[] chickens;
    Coroutine COChickenControl;
    Coroutine COLifeEgg;
    void Start()
    {
        if (cam == null)
        {
            cam = Camera.main;
        }
        Vector3 upperCorner = new Vector3(Screen.width, Screen.height, 0.0f);
        Vector3 targetWidth = cam.ScreenToWorldPoint(upperCorner);
        float eggWidth = egg.GetComponent<Renderer>().bounds.extents.x;
        maxWidth = targetWidth.x - eggWidth;
        chickens = GameObject.FindGameObjectsWithTag("Chicken");
        COChickenControl = StartCoroutine(chickenNormalEggLayingControl());
        COLifeEgg = StartCoroutine(chickenLifeEggLayingControl());
    }

    void Update()
    {
        UpdateText();
    }

    void UpdateText()
    {
        LifeText.text = "Remaining Life:\n" + (livesLeft).ToString();
        if (livesLeft == 0)
        {
            if (COChickenControl != null)
                StopCoroutine(COChickenControl);
            if (COLifeEgg != null)
                StopCoroutine(COLifeEgg);
            StartCoroutine(showEndGameMenu());
        }
    }

    IEnumerator showEndGameMenu()
    {
        yield return new WaitForSeconds(0.1f);
        if (gameOverText.activeSelf == false)
        {
            gameOverText.SetActive(true);
        }
        if (restartButton.activeSelf == false)
        {
            restartButton.SetActive(true);
        }
    }

    public IEnumerator chickenNormalEggLayingControl()
    {
        int chickenIndex = -1;
        float delayTime = 0;
        yield return new WaitForSeconds(1.0f);
        while (true)
        {
            chickenIndex = UnityEngine.Random.Range((int)0, (int)chickens.Length);
            delayTime = UnityEngine.Random.Range(1.0f, 3.0f);

            chickens[chickenIndex].GetComponent<ChickenScript>().LayEgg();
            yield return new WaitForSeconds(delayTime);
        }
    }

    public IEnumerator chickenLifeEggLayingControl()
    {
        int chickenIndex = -1;
        float delayTime = 0;
        yield return new WaitForSeconds(7.0f);
        while (true)
        {
            chickenIndex = UnityEngine.Random.Range((int)0, (int)chickens.Length);
            delayTime = UnityEngine.Random.Range(5.0f, 10.0f);

            chickens[chickenIndex].GetComponent<ChickenScript>().LayLifeEgg();
            yield return new WaitForSeconds(delayTime);
        }
    }


}
