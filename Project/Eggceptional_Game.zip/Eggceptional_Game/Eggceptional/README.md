# Eggceptional

Eggceptional is a game written in Unity 3D. This has two modes: one is untimed, the other is timed. After selecting a particular mode, you can catch the eggs in the basket below. You can go back to the main selection after the game is over. The game features sounds and exciting graphics!
